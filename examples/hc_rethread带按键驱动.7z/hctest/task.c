#include "all.h"
#include "task.h"
 /* 定义线程控制块 */
rt_thread_t task1 = RT_NULL;
rt_thread_t task2 = RT_NULL;
rt_thread_t button_scan_task = RT_NULL;

//
rt_uint8_t task1_stack[RT_TASK1_THREAD_STACK_SIZE];
struct rt_thread task1_thread;

rt_uint8_t task2_stack[RT_TASK2_THREAD_STACK_SIZE];
struct rt_thread task2_thread;

rt_uint8_t button_scan_stack[RT_BUTTON_SCAN_THREAD_STACK_SIZE];
struct rt_thread button_scan_thread;



int creat_task()
{
	rt_err_t result;
	rt_thread_t tid;	
	tid = &task1_thread;
	
	
    result = rt_thread_init(tid, "task1", task1_entry, RT_NULL,
                            task1_stack, sizeof(task1_stack), RT_TASK1_THREAD_PRIORITY, 20);
    RT_ASSERT(result == RT_EOK);
		rt_thread_startup(tid);
	
		tid = &task2_thread;
		result = rt_thread_init(tid, "task2", task2_entry, RT_NULL,
                            task2_stack, sizeof(task2_stack), RT_TASK2_THREAD_PRIORITY, 20);
    RT_ASSERT(result == RT_EOK);
		rt_thread_startup(tid);
	
		tid = &button_scan_thread;
		result = rt_thread_init(tid, "button_scan_task", button_scan_task_entry, RT_NULL,
                            button_scan_stack, sizeof(button_scan_stack), RT_BUTTON_SCAN_THREAD_PRIORITY, 20);
    RT_ASSERT(result == RT_EOK);
		rt_thread_startup(tid);
	
	
}


void task1_entry()
{
	int i;
	volatile char a[16];
	while (1)
  {
		for( i=0;i<10;i++)
			a[i]=i;
		Gpio_SetIO(EVB_LEDR_PORT, EVB_LEDR_PIN);
		rt_thread_delay(500);
		Gpio_ClrIO(EVB_LEDR_PORT, EVB_LEDR_PIN);
		rt_thread_delay(500);
  } 

}
void task2_entry()
{
	while (1)
  {
		Gpio_SetIO(EVB_LEDY_PORT, EVB_LEDY_PIN);
		rt_thread_delay(1000);
		Gpio_ClrIO(EVB_LEDY_PORT, EVB_LEDY_PIN);
		rt_thread_delay(1000);
  }

}

void button_scan_task_entry()
{
	while (1)
  {
		flex_button_scan();
		rt_thread_delay(20);	
  }
	

}