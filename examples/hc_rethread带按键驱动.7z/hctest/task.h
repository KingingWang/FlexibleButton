#ifndef __TASK_H__
#define __TASK_H__

#include "rtthread.h"
#define RT_TASK1_THREAD_STACK_SIZE 256
#define RT_TASK2_THREAD_STACK_SIZE 128
#define RT_BUTTON_SCAN_THREAD_STACK_SIZE 128
#define	RT_TASK1_THREAD_PRIORITY  1
#define	RT_TASK2_THREAD_PRIORITY  2
#define	RT_BUTTON_SCAN_THREAD_PRIORITY  1

extern  void led1_thread_entry(void* parameter); 
extern  void key_thread_entry(void* parameter);
extern  void button_scan_entry(void* parameter);

extern  rt_thread_t task1;
extern  rt_thread_t task2;
extern  rt_thread_t button_scan_task;

extern  rt_uint8_t task1_stack[];
extern struct rt_thread task1_thread;
 
extern  rt_uint8_t task2_stack[];
extern struct rt_thread task2_thread;

extern  rt_uint8_t button_scan_stack[];
extern struct rt_thread button_scan_thread;

int creat_task();
void task1_entry();
void task2_entry();
void button_scan_task_entry();
#endif