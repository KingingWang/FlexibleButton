#include "buttonapp.h"

typedef enum
{
  USER_BUTTON_0 = 0, //USER_KEY
	USER_BUTTON_1,
	USER_BUTTON_2,
  USER_BUTTON_MAX
} user_button_t;

static flex_button_t user_button[USER_BUTTON_MAX];

// 按键引脚电平读取函数，在这个函数内读取引脚电平
static uint8_t common_btn_read(void *arg)
{
  uint8_t value = 0;

  flex_button_t *btn = (flex_button_t *)arg;

  switch (btn->id)
  {
  case USER_BUTTON_0:
    value = Gpio_GetInputIO(GpioPortB, GpioPin0);
    break;
	case USER_BUTTON_1:
    value = Gpio_GetInputIO(GpioPortB, GpioPin1);
    break;
	case USER_BUTTON_2:
    value = Gpio_GetInputIO(GpioPortB, GpioPin2);
    break;
  default:
   break;
  }

  return value;
}

// 事件回调函数
static void common_btn_evt_cb(void *arg)
{
  static int b;
  flex_button_t *btn = (flex_button_t *)arg;

  switch (btn->id)
  {
  case USER_BUTTON_0:
  {
    switch (btn->event)
    {
    case FLEX_BTN_PRESS_DOWN:
      flex_btn_press_down_callback(); // 按下事件
      break;
    case FLEX_BTN_PRESS_CLICK:
      flex_btn_press_click_callback(); // 单击事件
      break;
    case FLEX_BTN_PRESS_DOUBLE_CLICK:
      flex_btn_press_double_click_callback(); // 双击事件
      break;
    case FLEX_BTN_PRESS_REPEAT_CLICK:
      flex_btn_press_repeat_click_callback(); // 连击事件，使用 flex_button_t 中的 click_cnt 断定连击次数
      break;
    case FLEX_BTN_PRESS_SHORT_START:
      flex_btn_press_short_start_callback(); // 短按开始事件
      break;
    case FLEX_BTN_PRESS_SHORT_UP:
      flex_btn_press_short_up_callback(); // 短按抬起事件
      break;
    case FLEX_BTN_PRESS_LONG_START:
      flex_btn_press_long_start_callback(); // 长按开始事件
      break;
    case FLEX_BTN_PRESS_LONG_UP:
      flex_btn_press_long_up_callback(); // 长按抬起事件
      break;
    case FLEX_BTN_PRESS_LONG_HOLD:
      flex_btn_press_long_hold_callback(); // 长按保持事件
      break;
    case FLEX_BTN_PRESS_LONG_HOLD_UP:
      flex_btn_press_long_hold_up_callback(); // 长按保持的抬起事件
      break;

    default:
      break;
    }
    break;
  }
  default:
    break;
  }
}
void user_button_init(void)
{
  int i;

  rt_memset(&user_button[0], 0x0, sizeof(user_button));
  for (i = 0; i < USER_BUTTON_MAX; i++)
  {
    user_button[i].id = i;  // 按键的ID号
    user_button[i].usr_button_read = common_btn_read; // 按键引脚电平读取函数
    user_button[i].cb = common_btn_evt_cb;            // 事件回调函数
    user_button[i].pressed_logic_level = PRESS_LOGIC; // 设置按键按下的逻辑电平
    user_button[i].click_cnt = 3;                     //连击次数，触发连击
    user_button[i].short_press_start_tick = FLEX_MS_TO_SCAN_CNT(1500);
    user_button[i].long_press_start_tick = FLEX_MS_TO_SCAN_CNT(3000);
    user_button[i].long_hold_start_tick = FLEX_MS_TO_SCAN_CNT(6000);

    flex_button_register(&user_button[i]);
  }
}

void flex_btn_press_down_callback() // 按下事件
{
}
void flex_btn_press_click_callback() // 单击事件
{
}
void flex_btn_press_double_click_callback() // 双击事件
{
}
void flex_btn_press_repeat_click_callback()  // 连击事件，使用 flex_button_t 中的 click_cnt 断定连击次数
{
}
void flex_btn_press_short_start_callback() // 短按开始事件
{
}
void flex_btn_press_short_up_callback() // 短按抬起事件
{
}
void flex_btn_press_long_start_callback() // 长按开始事件
{
}
void flex_btn_press_long_up_callback() // 长按抬起事件
{
}
void flex_btn_press_long_hold_callback() // 长按保持事件
{
}
void flex_btn_press_long_hold_up_callback() // 长按保持的抬起事件
{
}