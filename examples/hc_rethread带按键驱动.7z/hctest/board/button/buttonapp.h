#ifndef __BUTTONAPP_H__
#define __BUTTONAPP_H__

#include "main.h"
#include "flexible_button.h"
#include "gpio.h"
void user_button_init(void);
#define PRESS_LOGIC 0 //设置按下按键的电平，按需修改

void flex_btn_press_down_callback();         // 按下事件
void flex_btn_press_click_callback();        // 单击事件
void flex_btn_press_double_click_callback(); // 双击事件
void flex_btn_press_repeat_click_callback(); // 连击事件，使用 flex_button_t 中的 click_cnt 断定连击次数
void flex_btn_press_short_start_callback();  // 短按开始事件
void flex_btn_press_short_up_callback();     // 短按抬起事件
void flex_btn_press_long_start_callback();   // 长按开始事件
void flex_btn_press_long_up_callback();      // 长按抬起事件
void flex_btn_press_long_hold_callback();    // 长按保持事件
void flex_btn_press_long_hold_up_callback(); // 长按保持的抬起事件

#endif