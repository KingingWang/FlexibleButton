#include "sem.h"               
#include "all.h" 







